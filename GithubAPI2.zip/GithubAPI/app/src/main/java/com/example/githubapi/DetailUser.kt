package com.example.githubapi

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.githubapi.DetailViewModel.Companion.QUERY
import com.example.githubapi.databinding.ActivityDetailUserBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class DetailUser : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding
    companion object {
        const val USERNAME = "user_name"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }
    private lateinit var username : String
    private val detailViewModel by viewModels<DetailViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val intent = intent
        val bundle = intent.extras

        if (bundle != null) {
            username = bundle.getString(USERNAME).toString()
            QUERY = username
        }

        detailViewModel.userProfile.observe(this) { profile -> setUserProfile(profile) }
        detailViewModel.isLoading.observe(this) { showLoading(it) }

        val sectionsPagerAdapter = SectionsPagerAdapter(this,username)
        val viewPager: ViewPager2 = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs : TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

    }

    private fun setUserProfile(Profiles : UserProfile){
        binding.username.text = Profiles.login
        val uri = Profiles.avatarUrl
        Glide.with(this).load(uri).circleCrop().into(binding.profilepic)
        val followers : Int = Profiles.followers
        val following : Int = Profiles.following
        binding.followers.text = getString(R.string.followersCnt, followers)
        binding.following.text = getString(R.string.followingCnt, following)
        binding.name.text = Profiles.name

    }


    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}